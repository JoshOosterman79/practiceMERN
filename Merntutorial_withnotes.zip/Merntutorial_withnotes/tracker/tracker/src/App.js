import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; 
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/navbar.component";
import TodosList from "./components/todos-list.component";
import CreateTodo from "./components/create-todo.component";
import UpdateTodo from "./components/UpdateTodo";


function App() {
 return (
 <Router>
 <div className="container">
 <Navbar />
 <br />
 <Routes>
 <Route path="/" exact element={<TodosList />} />
 <Route path="/create" element={<CreateTodo />} />
 <Route path="/update/:id" element={<UpdateTodo />} />
 </Routes>
 </div>
 </Router>
 );
}
export default App;

