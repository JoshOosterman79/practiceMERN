import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // Hooks to get URL params and navigation
import axios from 'axios'; // Library for making HTTP requests

export default function UpdateTodo() {
  // `useParams` hook gives access to the URL parameter (in this case, `id`)
  const { id } = useParams();
  
  // `useNavigate` hook allows programmatic navigation (used after form submission)
  const navigate = useNavigate();
  
  // `activity` is the state that stores the value of the todo's activity
  const [activity, setActivity] = useState("");

  // `useEffect` hook to fetch the current todo data when the component loads
  useEffect(() => {
    // Make a GET request to fetch the todo item by its ID
    axios.get('http://localhost:5000/todos/' + id)
      .then(response => {
        // Set the activity state with the data from the response
        setActivity(response.data.activity);
      })
      .catch(error => {
        // Log any errors if the request fails
        console.log(error);
      });
  }, [id]); // The effect depends on `id`, so it will run whenever `id` changes

  // Function to handle form submission
  const onSubmit = (e) => {
    // Prevent the default form submission behavior
    e.preventDefault();

    // Create an object with the updated activity
    const updatedTodo = { activity };

    // Make a POST request to update the todo with the new data
    axios.post('http://localhost:5000/todos/update/' + id, updatedTodo)
      .then(res => {
        // Log the response from the server after updating the todo
        console.log(res.data);
        
        // Redirect back to the todos list after successful submission
        window.location = '/';
      })
      .catch(error => {
        // Log any errors if the request fails
        console.log(error);
      });
  };

  // Render the form with the current activity data
  return (
    <div>
      <h3>Update Todo</h3>
      <form onSubmit={onSubmit}>
        <div className="form-group">
          {/* Input field for activity */}
          <label>Activity: </label>
          <input 
            type="text"
            required
            className="form-control"
            value={activity} // Bind the input value to the `activity` state
            onChange={(e) => setActivity(e.target.value)} // Update state when input changes
          />
        </div>
        <div className="form-group">
          {/* Submit button for the form */}
          <input type="submit" value="Update Todo" className="btn btn-primary" />
        </div>
      </form>
    </div>
  );
}
