import React, { Component } from "react";
import axios from "axios";


export default class CreateTodo extends Component {
  // Constructor method that initializes state and binds event handler methods
  constructor(props) { 
    super(props); // Call the parent class (Component) constructor

    // Bind 'this' context to the event handlers so they can access 'this.state'
    this.onChangeActivity = this.onChangeActivity.bind(this);
    this.onSubmit = this.onSubmit.bind(this);

    // Initialize component state with an empty activity string
    this.state = {
      activity: "",
    };
  }

  // Event handler to update state when the input value changes
  onChangeActivity(e) {
    this.setState({
      activity: e.target.value, // Update the activity in state with the new input value
    });
  }

  // Event handler to handle form submission
  onSubmit(e) {
    e.preventDefault(); // Prevent the default form submission behavior (reloading the page)

    // Create an object with the current activity from the state
    const activityvar = {
      activity: this.state.activity,
    };

    // Log the activity object to the console (for debugging)
    console.log(activityvar);

    // Make a POST request to the server to add the new task (activity)
    axios
      .post("http://localhost:5000/todos/add", activityvar) // API endpoint
      .then((res) => {
        window.location = "/"; // Redirect to home page after successful submission
      });

    // Optional code (commented out):`
    // axios
    //  .post("http://localhost:5000/todos/add", activityvar)
    //  .then((res) => console.log(res.data)); // Logs response data from the server
  }

  // Render method to display the form in the UI
  render() {
    return (
      <div>
        <h3>Create New Task</h3>
        <form onSubmit={this.onSubmit}> {/* Form submission handled by onSubmit */}
          <div className="form-group">
            <label>New Task: </label>
            <input
              type="text"
              required // Makes the input field mandatory
              className="form-control" // Bootstrap class for styling
              value={this.state.activity} // Input value bound to component state
              onChange={this.onChangeActivity} // Update state when input value changes
            />
          </div>
          <div className="form-group">
            <input
              type="submit"
              value="Create Activity Log" // Text on the submit button
              className="btn btn-primary" // Bootstrap class for button styling
            />
          </div>
        </form>
      </div>
    );
  }
}
