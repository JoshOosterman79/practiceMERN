

# How to add an Update Feature.

This update feature would - 

1) direct from a activity selected, this would direct the user to a new page to update the Activity


